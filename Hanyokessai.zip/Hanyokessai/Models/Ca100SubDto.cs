namespace Hanyokessai.Models
{
    public class Ca100SubDto
    {
        public string templeteName { get; set; }
        public string templeteID { get; set; }
    }
}