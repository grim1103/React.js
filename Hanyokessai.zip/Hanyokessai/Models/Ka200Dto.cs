﻿using Microsoft.VisualBasic.CompilerServices;

namespace Hanyokessai.Models
{
    public class Ka200Dto
    {
        public string reportId { get; set; }
        public string templeteId { get; set; }
        public string drpbxSrchComCd { get; set; }
        public string txtAtTblNm { get; set; }
        public string txtApvlSts { get; set; }
        public string txtWrtMail { get; set; }
        public string txtWrtrNm { get; set; }
        public string txtApvlDtPlan { get; set; }
        public string dtChgeDay { get; set; }
        public string approvalMail1 { get; set; }
        public string approvalMail2 { get; set; }
        public string approvalMail3 { get; set; }
        public string approvalMail4 { get; set; }
        public string approvalMail5 { get; set; }
        public string approvalMail6 { get; set; }
        public string approvalMail7 { get; set; }
        public string approvalMail8 { get; set; }
        public string approvalMail9 { get; set; }
        public string approvalMail10 { get; set; }
        public string approvalMailLast { get; set; }
        public bool btnFlg { get; set; }
        public string file_binary { get; set; }
        public string report_file_size { get; set; }
        public string file_name { get; set; }
    }
}
