﻿namespace Hanyokessai.Models
{
    public class Ta200Dto
    {
        public string txtNo { get; set; }

        public string txtTempleteId { get; set; }

        public string txtTempleteName { get; set; }

        public string txtFileName { get; set; }

        public string txtFileBinary { get; set; }

        public string txtTempleteFileSize { get; set; }

        public string txtCom_cd { get; set; }

        public string txtRegName { get; set; }

        public string txtRegDate { get; set; }

        public string txtUpdName { get; set; }

        public string txtUpdDate { get; set; }

    }
}
