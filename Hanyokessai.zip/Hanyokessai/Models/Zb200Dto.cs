﻿namespace Hanyokessai.Models
{
    public class Zb200Dto
    {
        public string labelKaiinId { get; set; }

        public string labelPw { get; set; }

        public string labelKenGen { get; set; }

        public string labelKaiSyaMei { get; set; }

        public string labelSyoZoku1 { get; set; }

        public string labelSyoZoku2 { get; set; }

        public string labelSyoKui { get; set; }

        public string labelNyuSyaBi { get; set; }

        public string labelKauInMail { get; set; }

        public string labelKanJiSei { get; set; }

        public string labelKanJiMei { get; set; }

        public string labelKaNaSei { get; set; }

        public string labelKaNaMei { get; set; }

        public string labelEiGoSei { get; set; }

        public string labelEiGoMei { get; set; }

        public string labelSeiBeTu { get; set; }

        public string labelKaInTel { get; set; }

        public string labelPostNo { get; set; }

        public string labelAddress { get; set; }

        public string labelOuInUm { get; set; }

        public string labelOuInZyoHo { get; set; }

        public string labelSyuSeiBi { get; set; }

        public string labelSyuSeiSya { get; set; }

    }
}
