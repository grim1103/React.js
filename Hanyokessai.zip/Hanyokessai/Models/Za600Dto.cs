﻿namespace Hanyokessai.Models
{
    public class Za600Dto
    {
        public string labelMail { get; set; }
        
        public string labelKanjiName { get; set; }

        public string labelKanaName { get; set; }

        public string labelEngName { get; set; }

        public string labelGender { get; set; }

        public string labelCom { get; set; }

        public string labelDep1 { get; set; }

        public string labelDep2 { get; set; }

        public string labelPos { get; set; }

        public string labelPhone { get; set; }
        
        public string labelZip { get; set; }
        
        public string labelAdd { get; set; }
        
        public string labelEntryDate { get; set; }

        public string labelStamp { get; set; }

        public string imgStamp { get; set; }

    }
}
