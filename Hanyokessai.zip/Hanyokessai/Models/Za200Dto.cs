﻿namespace Hanyokessai.Models
{
    public class Za200Dto
    {
        public string member_id { get; set; }

    }
}
