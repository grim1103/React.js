﻿namespace Hanyokessai.Models
{
    public class Ta200MemDto
    {
        public string txtUpdName { get; set; }

    }
}
