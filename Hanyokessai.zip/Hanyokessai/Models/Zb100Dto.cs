﻿namespace Hanyokessai.Models
{
    public class Zb100Dto
    {
        public string labelId { get; set; }
        
        public string labelAuth { get; set; }

        public string labelMail { get; set; }

        public string labelName { get; set; }

        public string labelCom { get; set; }

        public string labelDep1 { get; set; }

        public string labelDep2 { get; set; }

        public string labelPos { get; set; }
        
        public string labelEntryDate { get; set; }

    }
}
