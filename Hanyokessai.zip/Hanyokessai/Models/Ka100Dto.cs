﻿namespace Hanyokessai.Models
{
    public class Ka100Dto
    {
        public string approvalWaitNum { get; set; }
        public string approvedNum { get; set; }
        public string approvalRejectNum { get; set; }
        public string approvalComplMonNum { get; set; }
        public string approvalComplTotNum { get; set; }
    }
}
