﻿namespace Hanyokessai.Models
{
    public class Za100Dto
    {
        public string member_id { get; set; }
        public string mail { get; set; }
        public string authority_cd { get; set; }

    }
}
