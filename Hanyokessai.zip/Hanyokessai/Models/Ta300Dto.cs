﻿namespace Hanyokessai.Models
{
    public class Ta300Dto
    {
        public string templete_name { get; set; }

        public string templete_detail { get; set; }

        public string file_name { get; set; }

        public string file_binary { get; set; }

        public string templete_file_size { get; set; }

        public string reg_com_cd { get; set; }

        public string reg_dep1_cd { get; set; }

        public string reg_dep2_cd { get; set; }

        public string reg_pos_cd { get; set; }

        public string reg_member_fistname { get; set; }

        public string reg_member_lastname { get; set; }

        public string reg_date { get; set; }

        public string upd_id { get; set; }

        public string upd_com_cd { get; set; }

        public string upd_dep1_cd { get; set; }

        public string upd_dep2_cd { get; set; }

        public string upd_pos_cd { get; set; }

        public string upd_member_fistname { get; set; }

        public string upd_member_lastname { get; set; }

        public string upd_date { get; set; }

        public string approval_place_start { get; set; }

        public string approval_place1 { get; set; }
        
        public string approval_place2 { get; set; }

        public string approval_place3 { get; set; }

        public string approval_place4 { get; set; }

        public string approval_place5 { get; set; }

        public string approval_place6 { get; set; }

        public string approval_place7 { get; set; }

        public string approval_place8 { get; set; }

        public string approval_place9 { get; set; }

        public string approval_place10 { get; set; }

        public string approval_place_last { get; set; }

        public string approval_status1 { get; set; }

        public string approval_status2 { get; set; }

        public string approval_status3 { get; set; }

        public string approval_status4 { get; set; }

        public string approval_status5 { get; set; }

        public string approval_status6 { get; set; }

        public string approval_status7 { get; set; }

        public string approval_status8 { get; set; }

        public string approval_status9 { get; set; }

        public string approval_status10 { get; set; }

        public string approval_status_last { get; set; }

        public string approval_mail1 { get; set; }

        public string approval_mail2 { get; set; }

        public string approval_mail3 { get; set; }

        public string approval_mail4 { get; set; }

        public string approval_mail5 { get; set; }

        public string approval_mail6 { get; set; }

        public string approval_mail7 { get; set; }

        public string approval_mail8 { get; set; }

        public string approval_mail9 { get; set; }

        public string approval_mail10 { get; set; }

        public string approval_mail_last { get; set; }

        public string upd_btn { get; set; }

        public string del_btn { get; set; }

        public string templete_id { get; set; }
    }

}

