var arr=[];
var arr2=[];
var stopBox=[];
var arrClass=[];
var standard =null;
var standardClass =null;
$(document).ready(function(){
    $('.video_img').each(function (index, item) {
        var div_height = $(this).height()/2;
        var div_offset = $(this).offset().top + div_height;
        var div_height2 = $(this).height();
        var div_offset2 = $(this).offset().top + div_height2;
        //동영상 정지/동작 제어 기준점
        arr.push(div_offset);
        //동영상 초기화 시점
        arr2.push(div_offset2);
        //기준이 될 동영상 
        arrClass.push($(item).children().eq(0));
    });
});
console.log(arr);
console.log(arr2);

var stop= false;
var stop2= false;
var stop3= false;
var stop4= false;
var stop5= false;
$(window).on("scroll",function(){
    var scroll_top=$(this).scrollTop();
    
    
    //첫번째 동영상 제어
    if(scroll_top<800){

        //최초 1회재생후 멈추기 설정
        $('.vid').bind('ended', function(){
            stop=true;
            
        });

        if(stop==false){
            if(scroll_top<400){
                //기준점보다 낮으면 영상플레이
                $('.vid').get(0).play();
            }else{
                //기준점보다 높으면 멈추기
                $('.vid').get(0).pause();
            }

        }else{
            //1회 재생시 영상멈추기
            $('.vid').get(0).pause();
        }

        //두번쨰 동영상 시작하기전 초기화
        if(scroll_top<100){
            $('.vid1').get(0).currentTime=0;
        }

    //스크롤이 800보다 클때
    }else{
        
        //1번째 동영상 초기화
        $('.vid').get(0).currentTime=0;
        stop=false;
        
        //최초 1회재생후 멈추기 설정
        $('.vid1').bind('ended', function(){
            stop2=true;
            
        });
        
        //두번째 동영상제어
        if(scroll_top<1700){
            
            if(stop2 == false){
                console.log('stop2==false');
                if(scroll_top<1300){
                    
                    $('.vid1').get(0).play();
                }else{
                    

                    $('.vid1').get(0).pause();
                }
            }else{

                //1회 재생시 영상멈추기
                $('.vid1').get(0).pause();
            }
            
            //세번쨰 동영상 시작하기전 초기화
            if(scroll_top<900){
                $('.vid2').get(0).currentTime=0;
            }
            
        }else{

            $('.vid1').get(0).currentTime=0;
            stop2=false;
            
            //최초 1회재생후 멈추기 설정
            $('.vid2').bind('ended', function(){
                stop3=true;
                
            });

            //세번째 동영상제어
            if(scroll_top<2597){
                
                if(stop3 == false){

                    if(scroll_top<2272){
                        
                        $('.vid2').get(0).play();
                    }else{
                        

                        $('.vid2').get(0).pause();
                    }
                }else{

                    //1회 재생시 영상멈추기
                    $('.vid2').get(0).pause();
                }

                //네번쨰 동영상 시작하기전 초기화
                if(scroll_top<1900){
                    $('.vid3').get(0).currentTime=0;
                }

                
            }else{

                $('.vid2').get(0).currentTime=0;
                stop3=false;

                //최초 1회재생후 멈추기 설정
                $('.vid3').bind('ended', function(){
                    stop4=true;
                    
                });

                
                //네번째 동영상제어
                if(scroll_top<3800){
                    
                    if(stop4 == false){

                        if(scroll_top<3206){
                            
                            $('.vid3').get(0).play();
                        }else{
                            

                            $('.vid3').get(0).pause();
                        }
                    }else{

                        //1회 재생시 영상멈추기
                        $('.vid3').get(0).pause();
                    }

                    //다섯번쨰 동영상 시작하기전 초기화
                    // if(scroll_top<2800){
                    //     $('.vid4').get(0).currentTime=0;
                        
                    // }
         
                }else{

                    $('.vid3').get(0).currentTime=0;
                    stop4=false;

                    //최초 1회재생후 멈추기 설정
                    $('.vid4').bind('ended', function(){
                        stop5=true;
                    });

                    //다섯번째 동영상제어
                    if(scroll_top<4441){
                        
                        if(stop5 == false){
                            
                            if(scroll_top<3600){
                                
                                $('.vid4').get(0).play();

                            }else{
                                
                                $('.vid4').get(0).pause();
                            }
                        }else{

                            //1회 재생시 영상멈추기
                            $('.vid4').get(0).pause();
                        }
                        
                    }else{

                        $('.vid4').get(0).currentTime=0;
                        stop5=false;   
                    }  
                }
                
            }
            
        }
        
    }     
    
       


    //스크롤이멈췄을때 작동
    $.fn.scrollEnd = function(callback, timeout) {
        $(this).scroll(function(){
            var $this = $(this);
            if ($this.data('scrollTimeout')) {
            clearTimeout($this.data('scrollTimeout'));
            }
        
            $this.data('scrollTimeout', setTimeout(callback,timeout));
        }); // 스크롤종료시를 감지하는 스크립트
    };

    $(window).scrollEnd(function(){
        if(scroll_top<200){
        
        
        $('.fix_btn1').animate({top:0});
        $('.fix_btn2').animate({left:114});
        
        }else if(scroll_top>200){
        
            $('.fix_btn1').animate({top:-65},200);
            $('.fix_btn2').animate({left:0},200);
            }
    },1000); 
});


    // var arr=[];
    // var arr2=[];
    // var stopBox=[];
    // var arrClass=[];
    // var standard =null;
    $(document).ready(function(){

       
        
    //     $('.video_img').each(function (index, item) {
    //         var div_height = $(this).height()/2;
    //         var div_offset = $(this).offset().top + div_height;
    //         var div_height2 = $(this).height();
    //         var div_offset2 = $(this).offset().top + div_height2;
    //         //동영상 제어 기준점
    //         arr.push(div_offset);
    //         arr2.push(div_offset2);
    //         //기준이 될 동영상 
    //         arrClass.push($(item).children().eq(0));
    //         stopBox.push('true');
            
    
    //         $(window).bind('mousewheel', function(event) {
                
    //             var scroll_top=$(this).scrollTop();
                
                
    //             if(event.originalEvent.wheelDelta >= 0) {
    //                 //스크롤 올리기
                    
    //                 for(i=0; i<arr.length; i++){
    //                     var standard=arr[i];
    //                     var standard2=arr2[i];
    //                     var standardClass=arrClass[i];

    //                     //처음부터 재생
    //                     if(scroll_top > standard2){
    //                         $(standardClass).get(0).currentTime=0;
    //                     }

    //                     //동영상 재생
    //                     if(scroll_top<standard){
    //                         $(standardClass).get(0).play();
                           
    //                     //동영상 정지
    //                     }else{
    //                         $(standardClass).get(0).pause();
    //                     }
    //                 }
                    
    //             }else {

    //                 //스크롤 내리기
    //                 for(i=0; i<arr.length; i++){

    //                 var standard=arr[i];
    //                 var standardClass=arrClass[i];
                    
                
    //                 if(scroll_top<standard){
                        
    //                     $(standardClass).get(0).play();
                        
    //                 }else{

    //                     $(standardClass).get(0).pause();  
    //                 } 
                    
    //             }
    //         }
    //     });
    // }); 
});


$(document).ready(function(){
    //상단바 마우스 호버시
    $('.bottom_list_items').mouseover(function(){
        $(this).css('border-bottom','5px solid black');   
        $(this).children('.product').css('display','block');
    });

    $('.bottom_list_items').mouseleave(function(){
                
        $(this).css('border-bottom','none');
        $(this).children('.product').css('display','none');  
        
    });

    $('.bottom_list_items').mouseleave(function(){
        $(this).css('border-bottom','none');
        $(this).children('.product').css('display','none');
        // $(this).css('font-weight','none'); 
        
        var a=$('.product_list_bottom').children();
        
        // a.css('display','block');
    });

    //상단바 첫번쨰 호버시 나오는 화면
    $('.product_list_top_item').mouseover(function(){
        $(this).css('border-bottom','2px solid black');
        
        var index=$(this).data('index');
        var a=$('.product_list_bottom').children().eq(index);
        a.css('display','block');
        $('.product_list_bottom_items').not(a).css('display','none');
    });
    $('.product_list_top_item').mouseleave(function(){
        $(this).css('border-bottom','none');
        
    });

    //회사소개 메뉴 나태내기
    $('.conponyInt').mouseover(function(){
        
        $('.conponyInt_list').css('display','block');
        
    });
    $('.conponyInt').mouseleave(function(){
        $('.conponyInt_list').css('display','none');
    
    });

    //회사소개 메뉴 없애기
    $('.conponyInt_list_items').hover(function(){
        $(this).css('background-color' , '#D3D3D3');
    });
    $('.conponyInt_list_items').mouseleave(function(){
        $(this).css('background-color' , 'white');
    });

    $('.conponyInt_list_items').hover(function(){
        $(this).css('background-color' , '#D3D3D3');
    });
    $('.conponyInt_list_items').mouseleave(function(){
        $(this).css('background-color' , 'white');
    });

    //우측 하단 버튼
    var fix_btn1= true;
    $('.fix_btn1').click(function(){
        $('.fix_btn1_p').toggleClass('change');
        if(fix_btn1==true){
           
            // $('.fix_btn1_p').css('background','url(https://www.lge.co.kr/lg5-common/images/icons/icon-more-plus-x.png)').css('background-size','40px');
            fix_btn1=false;
            $('.fix_btn1_list').css('display', 'block');
            
        }else{
          
            // $('.fix_btn1_p').css('background','url(https://www.lge.co.kr/lg5-common/images/icons/icon_img_floating_40.svg)').css('background-size','40px');
            fix_btn1=true;
            $('.fix_btn1_list').css('display', 'none');
        }   
    });
    $('.fix_btn2').click(function(){
        $('html,body').stop().animate({scrollTop:0},300);
    });

    //메뉴전체보기 클릭
    $('.all_menu_items').on('click',function(){
        $(this).toggleClass('change');
    });
    var open=true;
    $('.all_menu_items').click(function(){
        
       
        if(open==true){
            $('.footer_open').css('display','block');
            open=false;
        }else{
            $('.footer_open').css('display','none');
            open=true;
        }
    });
    var lenguege=true;
    $('.middle_items').click(function(){
        if(lenguege==true){
            $('.lenguege').css('display','block');
            lenguege=false;
            $('.middle_items').children('img').css({
                'transform':'rotate(180deg)'
            });
        }else{
            $('.lenguege').css('display','none');
            lenguege=true;
            $('.middle_items').children('img').css({
                'transform':'rotate(0deg)'
            });
        }
    });
    

    
});



